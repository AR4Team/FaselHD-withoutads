//
//  ViewController.swift
//  hhh
//
//  Created by Eyad on 19/07/1444 AH.
//

import UIKit
import HTMLKit
import WebKit
class ViewController: UIViewController, WKNavigationDelegate {
    let urls = "https://www.faselhd.ws"
        private let webv : WKWebView = {
            let prf = WKPreferences()
            prf.javaScriptEnabled = true
            let con = WKWebViewConfiguration()
            con.preferences = prf
            let webView = WKWebView(frame: .zero,configuration: con)
            return webView
        }()
        override func viewDidLoad() {
            super.viewDidLoad()
            view.addSubview(webv)
            webv.frame = view.bounds
            webv.navigationDelegate = self
            guard let url = URL(string: urls ?? "") else {
                return
            }
            webv.load(URLRequest(url: url))
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
          print("done")
        }
}
